package com.mrkun.bypass.keybind;

import com.mrkun.bypass.client.BypassMessage;
import com.mrkun.bypass.config.BypassConfig;
import com.mrkun.bypass.gui.BypassMenuScreen;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.minecraft.class_304;
import net.minecraft.class_310;
import net.minecraft.class_3675;
import org.lwjgl.glfw.GLFW;

public class KeyBindings {
    private static class_304 openMenuKey;
    private static class_304 flyKey;
    private static class_304 killAuraKey;
    private static class_304 speedKey;
    private static class_304 xrayKey;
    private static class_304 autoJumpKey;
    private static class_304 noFallKey;
    private static class_304 sprintKey;
    private static class_304 fullbrightKey;

    public static void register() {
        openMenuKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.open_menu",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_H,
                "category.mrkunbypass"
        ));

        flyKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.fly",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_F,
                "category.mrkunbypass"
        ));

        killAuraKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.killaura",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_K,
                "category.mrkunbypass"
        ));

        speedKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.speed",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_V,
                "category.mrkunbypass"
        ));

        xrayKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.xray",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_X,
                "category.mrkunbypass"
        ));

        autoJumpKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.autojump",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_J,
                "category.mrkunbypass"
        ));

        noFallKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.nofall",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_N,
                "category.mrkunbypass"
        ));

        sprintKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.sprint",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_Z,
                "category.mrkunbypass"
        ));

        fullbrightKey = KeyBindingHelper.registerKeyBinding(new class_304(
                "key.mrkunbypass.fullbright",
                class_3675.class_307.field_1668,
                GLFW.GLFW_KEY_B,
                "category.mrkunbypass"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            handleKeyPresses();
        });
    }

    private static void handleKeyPresses() {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        while (openMenuKey.method_1436()) {
            client.method_1507(new BypassMenuScreen());
        }

        while (flyKey.method_1436()) {
            toggleModule("Fly");
        }

        while (killAuraKey.method_1436()) {
            toggleModule("KillAura");
        }

        while (speedKey.method_1436()) {
            toggleModule("Speed");
        }

        while (xrayKey.method_1436()) {
            toggleModule("Xray");
        }

        while (autoJumpKey.method_1436()) {
            toggleModule("AutoJump");
        }

        while (noFallKey.method_1436()) {
            toggleModule("NoFall");
        }

        while (sprintKey.method_1436()) {
            toggleModule("Sprint");
        }

        while (fullbrightKey.method_1436()) {
            toggleModule("Fullbright");
        }
    }

    private static void toggleModule(String moduleName) {
        BypassConfig.toggleModule(moduleName);
        boolean enabled = BypassConfig.isModuleEnabled(moduleName);
        BypassMessage.sendModuleToggleMessage(moduleName, enabled);
    }
}
