package com.mrkun.bypass;

import com.mrkun.bypass.config.BypassConfig;
import com.mrkun.bypass.gui.WelcomeScreen;
import com.mrkun.bypass.keybind.KeyBindings;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.networking.v1.ClientPlayConnectionEvents;
import net.fabricmc.fabric.api.client.rendering.v1.HudRenderCallback;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

public class MrkunBypassClient implements ClientModInitializer {
    public static final String MOD_ID = "mrkunbypass";
    public static final Logger LOGGER = LoggerFactory.getLogger(MOD_ID);

    private static long startupMessageEndTime = 0;
    private static boolean startupMessageShown = false;

    @Override
    public void onInitializeClient() {
        LOGGER.info("Mrkun Bypass loaded - troll client-side mod started!");

        BypassConfig.load();
        KeyBindings.register();

        // Show the welcome screen the first time the player joins a world.
        ClientPlayConnectionEvents.JOIN.register((handler, sender, client) -> {
            if (client.field_1724 == null) return;
            if (BypassConfig.isFirstLaunch()) {
                client.execute(() -> {
                    if (client.field_1755 == null) {
                        client.method_1507(new WelcomeScreen(null));
                    }
                });
            }
        });

        // Render the startup notification in the top-left corner for a few seconds.
        HudRenderCallback.EVENT.register((context, tickDelta) -> {
            class_310 client = class_310.method_1551();
            if (client.field_1724 == null || client.field_1755 != null) return;
            if (!BypassConfig.isShowStartupNotification()) return;
            if (startupMessageShown) return;

            if (startupMessageEndTime == 0) {
                startupMessageEndTime = System.currentTimeMillis() + 5000;
            }

            if (System.currentTimeMillis() > startupMessageEndTime) {
                startupMessageShown = true;
                return;
            }

            class_2561 message = class_2561.method_43470("Mrkun Bypass")
                    .method_27695(class_124.field_1065, class_124.field_1067)
                    .method_10852(class_2561.method_43470(" has been started!").method_27695(class_124.field_1060, class_124.field_1067));

            context.method_27535(client.field_1772, message, 10, 10, 0xFFFFFF);
        });
    }
}
