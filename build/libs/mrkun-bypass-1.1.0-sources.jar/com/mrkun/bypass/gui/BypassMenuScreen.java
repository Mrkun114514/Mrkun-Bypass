package com.mrkun.bypass.gui;

import com.mrkun.bypass.config.BypassConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class BypassMenuScreen extends class_437 {
    private static final int BUTTON_WIDTH = 200;
    private static final int BUTTON_HEIGHT = 25;
    private static final int BUTTON_SPACING = 5;
    private static final int TOP_MARGIN = 60;
    private static final int BOTTOM_MARGIN = 40;

    private final java.util.List<ModuleButton> moduleButtons = new java.util.ArrayList<>();
    private int scrollOffset = 0;
    private int contentHeight = 0;
    private int listTop;
    private int listBottom;
    private class_4185 configButton;

    public BypassMenuScreen() {
        super(class_2561.method_43470("Mrkun Bypass Menu"));
    }

    @Override
    protected void method_25426() {
        moduleButtons.clear();
        String[] modules = BypassConfig.getModuleNames();

        listTop = TOP_MARGIN;
        listBottom = this.field_22790 - BOTTOM_MARGIN;
        int x = (this.field_22789 - BUTTON_WIDTH) / 2;

        for (int i = 0; i < modules.length; i++) {
            String moduleName = modules[i];
            ModuleButton button = new ModuleButton(
                    x, 0, BUTTON_WIDTH, BUTTON_HEIGHT,
                    moduleName,
                    btn -> {
                        BypassConfig.toggleModule(moduleName);
                        com.mrkun.bypass.client.BypassMessage.sendModuleToggleMessage(moduleName, BypassConfig.isModuleEnabled(moduleName));
                        updateButtonStates();
                    }
            );
            moduleButtons.add(button);
            this.method_37063(button);
        }

        // Settings button at the bottom right of the menu area
        configButton = class_4185.method_46430(class_2561.method_43470("Settings"), btn -> {
                    if (this.field_22787 != null) {
                        this.field_22787.method_1507(new ConfigScreen(this));
                    }
                })
                .method_46434(this.field_22789 - 90, this.field_22790 - 30, 80, 20)
                .method_46431();
        this.method_37063(configButton);

        contentHeight = modules.length * (BUTTON_HEIGHT + BUTTON_SPACING) - BUTTON_SPACING;
        clampScrollOffset();
        layoutButtons();
        updateButtonStates();
    }

    private void clampScrollOffset() {
        int listHeight = Math.max(0, listBottom - listTop);
        int maxScroll = Math.max(0, contentHeight - listHeight);
        scrollOffset = net.minecraft.class_3532.method_15340(scrollOffset, 0, maxScroll);
    }

    private void layoutButtons() {
        int x = (this.field_22789 - BUTTON_WIDTH) / 2;
        for (int i = 0; i < moduleButtons.size(); i++) {
            ModuleButton button = moduleButtons.get(i);
            int y = listTop + i * (BUTTON_HEIGHT + BUTTON_SPACING) - scrollOffset;
            button.method_46421(x);
            button.method_46419(y);
            button.field_22764 = y + BUTTON_HEIGHT > listTop && y < listBottom;
        }
    }

    private void updateButtonStates() {
        for (ModuleButton button : moduleButtons) {
            button.updateState();
        }
    }

    @Override
    public void method_25410(net.minecraft.class_310 client, int width, int height) {
        super.method_25410(client, width, height);
        listTop = TOP_MARGIN;
        listBottom = this.field_22790 - BOTTOM_MARGIN;
        clampScrollOffset();
        layoutButtons();
    }

    @Override
    public boolean method_25401(double mouseX, double mouseY, double horizontalAmount, double verticalAmount) {
        int listHeight = Math.max(0, listBottom - listTop);
        int maxScroll = Math.max(0, contentHeight - listHeight);
        if (maxScroll > 0) {
            scrollOffset = net.minecraft.class_3532.method_15340(scrollOffset - (int) (verticalAmount * 20), 0, maxScroll);
            layoutButtons();
        }
        return super.method_25401(mouseX, mouseY, horizontalAmount, verticalAmount);
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        if (this.field_22787 != null && this.field_22787.field_1687 != null) {
            context.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);
        } else {
            super.method_25420(context, mouseX, mouseY, delta);
        }

        if (BypassConfig.isBackgroundBlur() && this.field_22787 != null && this.field_22787.field_1687 != null) {
            this.method_57734(delta);
        }
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Mrkun Bypass").method_27695(class_124.field_1068, class_124.field_1067)
                        .method_10852(class_2561.method_43470(" | Modules").method_27692(class_124.field_1061)),
                this.field_22789 / 2, 20, 0xFFFFFF);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Press H to close").method_27692(class_124.field_1080),
                this.field_22789 / 2, 36, 0xAAAAAA);

        int listHeight = Math.max(0, listBottom - listTop);
        int maxScroll = Math.max(0, contentHeight - listHeight);
        if (maxScroll > 0) {
            int trackHeight = listHeight;
            int thumbHeight = Math.max(20, listHeight * listHeight / contentHeight);
            int thumbY = listTop + (scrollOffset * (trackHeight - thumbHeight) / maxScroll);
            int scrollbarX = (this.field_22789 + BUTTON_WIDTH) / 2 + 8;
            context.method_25294(scrollbarX, listTop, scrollbarX + 4, listBottom, 0x40FFFFFF);
            context.method_25294(scrollbarX, thumbY, scrollbarX + 4, thumbY + thumbHeight, 0xFFFFFFFF);
        }

        context.method_44379(0, listTop, this.field_22789, listBottom);
        super.method_25394(context, mouseX, mouseY, delta);
        context.method_44380();
    }

    @Override
    public boolean method_25421() {
        return false;
    }

    @Override
    public boolean method_25404(int keyCode, int scanCode, int modifiers) {
        if (keyCode == 72) { // GLFW_KEY_H
            this.method_25419();
            return true;
        }
        return super.method_25404(keyCode, scanCode, modifiers);
    }

    private class ModuleButton extends class_4185 {
        private final String moduleName;

        public ModuleButton(int x, int y, int width, int height, String message, class_4241 onPress) {
            super(x, y, width, height, class_2561.method_43470(message), onPress, class_4185.field_40754);
            this.moduleName = message;
            updateState();
        }

        public void updateState() {
            boolean enabled = BypassConfig.isModuleEnabled(moduleName);
            class_124 statusColor = enabled ? class_124.field_1060 : class_124.field_1061;
            class_124 bracketColor = class_124.field_1080;
            String status = enabled ? "ON" : "OFF";
            String arrow = enabled ? ">> " : " ";
            this.method_25355(class_2561.method_43470(arrow + moduleName + " ").method_27692(class_124.field_1068)
                    .method_10852(class_2561.method_43470("[").method_27692(bracketColor))
                    .method_10852(class_2561.method_43470(status).method_27695(statusColor, class_124.field_1067))
                    .method_10852(class_2561.method_43470("]").method_27692(bracketColor)));
        }

        @Override
        public void method_48579(class_332 context, int mouseX, int mouseY, float delta) {
            if (!this.field_22764) return;

            boolean enabled = BypassConfig.isModuleEnabled(moduleName);
            int bgColor;
            int bgHoverColor;

            if (this.method_49606()) {
                bgColor = enabled ? 0x8000AA00 : 0x80AA0000;
                bgHoverColor = enabled ? 0xA000DD00 : 0xA0DD0000;
            } else {
                bgColor = enabled ? 0x50006600 : 0x50660000;
                bgHoverColor = bgColor;
            }

            context.method_25296(this.method_46426(), this.method_46427(), this.method_46426() + this.field_22758, this.method_46427() + this.field_22759, bgColor, bgHoverColor);

            int borderColor = enabled ? 0xFF55FF55 : 0xFFFF5555;
            context.method_49601(this.method_46426(), this.method_46427(), this.field_22758, this.field_22759, borderColor);

            context.method_27534(field_22793, this.method_25369(),
                    this.method_46426() + this.field_22758 / 2,
                    this.method_46427() + (this.field_22759 - 8) / 2,
                    0xFFFFFF);
        }
    }
}
