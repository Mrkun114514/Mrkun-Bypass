package com.mrkun.bypass.gui;

import com.mrkun.bypass.config.BypassConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class WelcomeScreen extends class_437 {
    private final class_437 parent;

    public WelcomeScreen(class_437 parent) {
        super(class_2561.method_43470("Welcome to Mrkun Bypass"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 150;
        int x = (this.field_22789 - buttonWidth) / 2;
        int y = this.field_22790 - 50;
        this.method_37063(class_4185.method_46430(class_2561.method_43470("Got it!"), btn -> this.method_25419())
                .method_46434(x, y, buttonWidth, 20)
                .method_46431());
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xEE000000);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        int centerX = this.field_22789 / 2;
        int y = 40;

        context.method_27534(this.field_22793,
                class_2561.method_43470("Mrkun Bypass").method_27695(class_124.field_1065, class_124.field_1067),
                centerX, y, 0xFFFFFF);
        y += 30;

        String[] lines = {
                "This is a fun / troll client-side mod.",
                "It simulates hack-style toggle messages in chat,",
                "but it does NOT actually modify gameplay.",
                "",
                "Press H to open the module menu.",
                "Use the number keys or the menu to toggle modules.",
                "",
                "Enjoy the show!"
        };

        for (String line : lines) {
            if (line.isEmpty()) {
                y += 10;
            } else {
                context.method_27534(this.field_22793,
                        class_2561.method_43470(line).method_27692(class_124.field_1068),
                        centerX, y, 0xFFFFFF);
                y += 12;
            }
        }
    }

    @Override
    public void method_25419() {
        BypassConfig.setFirstLaunch(false);
        if (this.field_22787 != null) {
            this.field_22787.method_1507(null);
        }
    }
}
