package com.mrkun.bypass.gui;

import com.mrkun.bypass.config.BypassConfig;
import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_332;
import net.minecraft.class_4185;
import net.minecraft.class_437;

public class ConfigScreen extends class_437 {
    private final class_437 parent;

    public ConfigScreen(class_437 parent) {
        super(class_2561.method_43470("Mrkun Bypass Options"));
        this.parent = parent;
    }

    @Override
    protected void method_25426() {
        int buttonWidth = 200;
        int x = (this.field_22789 - buttonWidth) / 2;
        int y = this.field_22790 / 2 - 40;

        // Toggle startup notification
        class_4185 startupButton = class_4185.method_46430(
                        getStartupText(),
                        btn -> {
                            BypassConfig.setShowStartupNotification(!BypassConfig.isShowStartupNotification());
                            btn.method_25355(getStartupText());
                        })
                .method_46434(x, y, buttonWidth, 20)
                .method_46431();
        this.method_37063(startupButton);

        y += 30;

        // Toggle background blur
        class_4185 blurButton = class_4185.method_46430(
                        getBlurText(),
                        btn -> {
                            BypassConfig.setBackgroundBlur(!BypassConfig.isBackgroundBlur());
                            btn.method_25355(getBlurText());
                        })
                .method_46434(x, y, buttonWidth, 20)
                .method_46431();
        this.method_37063(blurButton);

        y += 50;

        this.method_37063(class_4185.method_46430(class_2561.method_43470("Done"), btn -> this.method_25419())
                .method_46434(x, y, buttonWidth, 20)
                .method_46431());
    }

    private class_2561 getStartupText() {
        boolean enabled = BypassConfig.isShowStartupNotification();
        return class_2561.method_43470("Startup Notification: ")
                .method_10852(class_2561.method_43470(enabled ? "ON" : "OFF")
                        .method_27692(enabled ? class_124.field_1060 : class_124.field_1061));
    }

    private class_2561 getBlurText() {
        boolean enabled = BypassConfig.isBackgroundBlur();
        return class_2561.method_43470("Menu Background Blur: ")
                .method_10852(class_2561.method_43470(enabled ? "ON" : "OFF")
                        .method_27692(enabled ? class_124.field_1060 : class_124.field_1061));
    }

    @Override
    public void method_25420(class_332 context, int mouseX, int mouseY, float delta) {
        context.method_25294(0, 0, this.field_22789, this.field_22790, 0xCC000000);
    }

    @Override
    public void method_25394(class_332 context, int mouseX, int mouseY, float delta) {
        this.method_25420(context, mouseX, mouseY, delta);
        super.method_25394(context, mouseX, mouseY, delta);

        context.method_27534(this.field_22793,
                class_2561.method_43470("Mrkun Bypass").method_27695(class_124.field_1065, class_124.field_1067),
                this.field_22789 / 2, 20, 0xFFFFFF);
        context.method_27534(this.field_22793,
                class_2561.method_43470("Settings").method_27692(class_124.field_1068),
                this.field_22789 / 2, 36, 0xAAAAAA);
    }

    @Override
    public void method_25419() {
        this.field_22787.method_1507(parent);
    }
}
