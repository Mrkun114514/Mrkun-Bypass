package com.mrkun.bypass.config;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;
import com.google.gson.reflect.TypeToken;
import com.mrkun.bypass.MrkunBypassClient;
import net.fabricmc.loader.api.FabricLoader;

import java.io.IOException;
import java.io.Reader;
import java.io.Writer;
import java.nio.file.Files;
import java.nio.file.Path;
import java.util.HashMap;
import java.util.Map;

public class BypassConfig {
    private static final Gson GSON = new GsonBuilder().setPrettyPrinting().create();
    private static final String CONFIG_FOLDER = "Mrkun_Bypass_config";
    private static final String CONFIG_FILE = "mrkun_bypass_config.json";

    private static final Map<String, Boolean> MODULE_STATES = new HashMap<>();
    private static boolean showStartupNotification = true;
    private static boolean backgroundBlur = false;
    private static boolean firstLaunch = true;

    static {
        MODULE_STATES.put("Fly", false);
        MODULE_STATES.put("KillAura", false);
        MODULE_STATES.put("Speed", false);
        MODULE_STATES.put("Xray", false);
        MODULE_STATES.put("AutoJump", false);
        MODULE_STATES.put("NoFall", false);
        MODULE_STATES.put("Sprint", false);
        MODULE_STATES.put("Fullbright", false);
    }

    public static void load() {
        Path configDir = FabricLoader.getInstance().getGameDir().resolve(CONFIG_FOLDER);
        Path configPath = configDir.resolve(CONFIG_FILE);
        try {
            if (!Files.exists(configDir)) {
                Files.createDirectories(configDir);
                MrkunBypassClient.LOGGER.info("Created config directory: {}", configDir);
            }

            if (Files.exists(configPath)) {
                try (Reader reader = Files.newBufferedReader(configPath)) {
                    ConfigData data = GSON.fromJson(reader, ConfigData.class);
                    if (data != null) {
                        if (data.modules != null) {
                            for (Map.Entry<String, Boolean> entry : data.modules.entrySet()) {
                                if (MODULE_STATES.containsKey(entry.getKey())) {
                                    MODULE_STATES.put(entry.getKey(), entry.getValue());
                                }
                            }
                        }
                        showStartupNotification = data.showStartupNotification;
                        backgroundBlur = data.backgroundBlur;
                        firstLaunch = data.firstLaunch;
                    }
                }
            } else {
                save();
            }
        } catch (Exception e) {
            MrkunBypassClient.LOGGER.error("Failed to load Mrkun Bypass config", e);
        }
    }

    public static void save() {
        Path configDir = FabricLoader.getInstance().getGameDir().resolve(CONFIG_FOLDER);
        Path configPath = configDir.resolve(CONFIG_FILE);
        try {
            if (!Files.exists(configDir)) {
                Files.createDirectories(configDir);
            }
            ConfigData data = new ConfigData();
            data.modules = new HashMap<>(MODULE_STATES);
            data.showStartupNotification = showStartupNotification;
            data.backgroundBlur = backgroundBlur;
            data.firstLaunch = firstLaunch;
            try (Writer writer = Files.newBufferedWriter(configPath)) {
                GSON.toJson(data, writer);
            }
        } catch (IOException e) {
            MrkunBypassClient.LOGGER.error("Failed to save Mrkun Bypass config", e);
        }
    }

    public static boolean isModuleEnabled(String moduleName) {
        return MODULE_STATES.getOrDefault(moduleName, false);
    }

    public static void toggleModule(String moduleName) {
        MODULE_STATES.put(moduleName, !isModuleEnabled(moduleName));
        save();
    }

    public static void setModule(String moduleName, boolean enabled) {
        MODULE_STATES.put(moduleName, enabled);
        save();
    }

    public static Map<String, Boolean> getAllModules() {
        return new HashMap<>(MODULE_STATES);
    }

    public static String[] getModuleNames() {
        return MODULE_STATES.keySet().toArray(new String[0]);
    }

    public static boolean isShowStartupNotification() {
        return showStartupNotification;
    }

    public static void setShowStartupNotification(boolean value) {
        showStartupNotification = value;
        save();
    }

    public static boolean isBackgroundBlur() {
        return backgroundBlur;
    }

    public static void setBackgroundBlur(boolean value) {
        backgroundBlur = value;
        save();
    }

    public static boolean isFirstLaunch() {
        return firstLaunch;
    }

    public static void setFirstLaunch(boolean value) {
        firstLaunch = value;
        save();
    }

    private static class ConfigData {
        Map<String, Boolean> modules;
        boolean showStartupNotification = true;
        boolean backgroundBlur = false;
        boolean firstLaunch = true;
    }
}
