package com.mrkun.bypass.client;

import net.minecraft.class_124;
import net.minecraft.class_2561;
import net.minecraft.class_310;
import net.minecraft.class_5250;

public class BypassMessage {

    public static void sendModuleToggleMessage(String moduleName, boolean enabled) {
        class_310 client = class_310.method_1551();
        if (client.field_1724 == null) return;

        class_5250 prefix = class_2561.method_43470("Mrkun Bypass").method_27692(class_124.field_1068);
        class_5250 separator = class_2561.method_43470("：").method_27692(class_124.field_1068);
        class_5250 module = class_2561.method_43470(moduleName).method_27692(class_124.field_1061);
        class_5250 status = class_2561.method_43470(enabled ? "已开启！" : "已关闭！").method_27692(class_124.field_1061);

        class_5250 message = prefix.method_10852(separator).method_10852(module).method_10852(class_2561.method_43470(" ").method_27692(class_124.field_1070)).method_10852(status);
        client.field_1724.method_7353(message, false);
    }
}
